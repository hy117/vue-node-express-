<template>
  <div>
    <el-row :style="bgImg">
      <el-col :xs="20" :sm="20" :md="20" :lg="20" :xl="18">
        <div class="grid-content bg-purple">
          <div class="header-left">
            <div class="nav">
              <i class="el-icon-house"></i>
              <span class="nav-span web-font" @click="index">首页</span>
            </div>
            <div class="nav">
              <i class="el-icon-headset"></i>
              <span class="nav-span web-font" @click="discovery">音乐</span>
            </div>
            <div class="nav">
              <i class="el-icon-chat-line-square"></i>
              <span class="nav-span web-font" @click="plate">留言板</span>
            </div>
            <div class="nav">
              <i class="el-icon-s-promotion"></i>
              <span class="nav-span web-font" @click="file">归档</span>
            </div>
            <div class="nav">
              <i class="el-icon-user"></i>
              <span class="nav-span web-font" @click="about">关于我</span>
            </div>
            <div class="nav">
              <i class="el-icon-tickets"></i>
              <span class="nav-span web-font" @click="article">文章</span>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :xs="4" :sm="4" :md="4" :lg="4" :xl="6">
        <el-dropdown @command="handleDropDown">
          <span class="el-dropdown-link">
            <span style="color: white">欢迎你:{{ username }}</span
            ><i
              style="color: white"
              class="el-icon-arrow-down el-icon--right"
            ></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="register">注册</el-dropdown-item>
            <el-dropdown-item command="login">登录</el-dropdown-item>
            <el-dropdown-item command="outLogin">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { userInfo } from "@/api/user.js";
// import { bus } from "../../main";
export default {
  name: "HeaderTop",
  data() {
    return {
      username: "",
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100%", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
      //当前用户
      abc: "",
    };
  },
  methods: {
    async getData(val) {
     this.$EventBus.$on("username", (val) => {
        // console.log(`val`, val);
        this.username = val;
        console.log(` this.username`, this.username);
        // console.log(this.username);
        console.log(this);
        // this.getData(val);
      });
    },
    handleDropDown(val) {
      if (val === "login") {
        this.$router.push("/login");
      }
      if (val === "register") {
        this.$router.push("/register");
      }
      if (val === "outLogin") {
        window.localStorage.removeItem("t_k");
        this.$message({
          type: "success",
          message: "退出登录",
        });
      }
    },
    article() {
      this.$router.push("/article");
    },
    index() {
      this.$router.push("/");
    },
    discovery() {
      this.$router.push("/main");
    },
    plate() {
      // this.$router.push("/plate");
      alert('还没做...')
    },
    file() {
      this.$router.push("/file");
    },
    about() {
      this.$router.push("/about");
    },
  },
  created() {
    this.getData();
  },
};
</script>

<style  lang="less" scoped>
.el-dropdown {
  // border: 1px solid red;
  cursor: pointer;
  // display: flex;
  // justify-content: center;
  height: 50px;
  line-height: 50px;
  // position: absolute;
  right: 10%;
}
.header-left,
.header-right {
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 17px;
  letter-spacing: 1px;
  .nav {
    height: 50px;
    line-height: 50px;
    margin-right: 20px;
    padding: 0 10px;

    span,
    i {
      color: white;
      margin-right: 1px;
    }
  }
  .nav:hover {
    background: rgba(73, 69, 107, 0.7);
    cursor: pointer;
  }
}
.el-row {
  background: rgba(40, 42, 44, 0.3) !important;
}
.nav-span {
  font-size: 17px;
}
</style>