<template>
  <div>
    <div class="bannerMan" ref="demo" v-show="show">
      <img src="@/assets/images/tou.jpg" alt="" />
      <p>The first blog 1.0</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      num: 1,
      show: true,
    };
  },
  methods: {
    height() {
      // console.log(window.innerHeight);
      if (window.innerHeight <= 750) {
        // let demo = document.querySelector('.bannerMan')
        // console.log(`this.$refs.demo`, this.$refs.demo);
        // console.log(this.$refs);
        // console.log(demo);
        //  this.$refs.demo.style.display = 'none'
        this.show = false
        // console.log(this.show);
      } else {
        // this.$refs.demo.style.display = 'block'
        //  this.$router.go(0)
         this.show = true
      }
    },
  },
  mounted() {
    this.height();
  },
};
</script>

<style scoped>
.bannerMan {
  width: 1100px;
  height: 300px;
  background: rgba(230, 244, 249, 0.8);
  margin: auto;
  z-index: 999;
  border-radius: 15px;
  cursor: pointer;
  opacity: 0.9;
  position: absolute;
  top: 600px;
  left: 50%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  -ms-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
.bannerMan p {
  text-align: center;
  font-size: 20px;
  background-image: -webkit-linear-gradient(bottom, red, #fd8403, pink);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
.bannerMan img {
  width: 100px;
  height: 100px;
  border-radius: 100%;
  transition: all 0.4s ease-in-out;
  -webkit-transition: all 0.4s ease-in-out;
  object-fit: cover;
  position: relative;
  top: -20px;
}

.bannerMan img:hover {
  transform: rotate(360deg);
  -webkit-transform: rotate(360deg);
}
.bannerMan:hover {
  box-shadow: 0px 0px 10px 2px rgba(120, 10, 249, 0.5);
  transform: translate(-50%, -55%);
}
@media screen and (max-width: 1920px) {
  .bannerMan {
    width: 1300px;
  }
}
@media screen and (max-width: 1200px) {
  .bannerMan {
    width: 900px;
  }
}
@media screen and (max-width: 992px) {
  .bannerMan {
    width: 700px;
  }
}
@media screen and (max-width: 768px) {
  .bannerMan {
    width: 400px;
  }
}
</style>