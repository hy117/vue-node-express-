<template>
  <div>
    <el-card class="header">
      <transition appear name="bounce" :duration="1000">
        <img src="@/assets/images/公告.png" alt="" class="ballon" />
      </transition>
      <span>公告</span>
      <transition appear name="text" :duration="1000">
        <h5 class="text">终于等到你!</h5>
      </transition>
    </el-card>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
.el-card {
  width: 360px;
  margin: 50px auto;
  display: flex;
  justify-content: center;
  position: relative;
  span {
    margin-left: 10px;
    top: 20px;
    position: absolute;
  }
  h5 {
    margin-top: 20px;
    font-size: 15px;
  }
}
.el-card:hover {
  cursor: pointer;
}
//文本
.text-enter-active {
  animation: bounce-in 0.5s;
}
.text-leave-active {
  animation: bounce-in 0.5s reverse;
}
.text {
  -webkit-animation-name: text; /*关键帧名称*/
  -webkit-animation-timing-function: ease-in-out; /*动画的速度曲线*/
  -webkit-animation-iteration-count: infinite; /*动画播放的次数*/
  -webkit-animation-duration: 5s; /*动画所花费的时间*/
}
.bounce-enter-active {
  animation: bounce-in 0.5s;
}
.bounce-leave-active {
  animation: bounce-in 0.5s reverse;
}
.ballon {
  -webkit-animation-name: scaleDraw; /*关键帧名称*/
  -webkit-animation-timing-function: ease-in-out; /*动画的速度曲线*/
  -webkit-animation-iteration-count: infinite; /*动画播放的次数*/
  -webkit-animation-duration: 5s; /*动画所花费的时间*/
  width: 10%;
}
@keyframes scaleDraw {
  0% {
    opacity: 0.7;
    transform: scale(1);
  }
  25% {
    opacity: 1;
    transform: scale(1.4);
  }
  50% {
    opacity: 0.7;
    transform: scale(1);
  }
  75% {
    opacity: 1;
    transform: scale(1.4);
  }
  100% {
    opacity: 0.7;
    transform: scale(1);
  }
}
@keyframes text {
  0% {
    transform: translateX(30px);
  }
  50% {
    transform: translateX(150px);
  }
  100% {
    transform: translateX(30px);
  }
}
</style>