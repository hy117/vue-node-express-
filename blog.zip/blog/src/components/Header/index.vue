<template>
  <div :style="bgImg" class="bg">
    <header-top></header-top>
    <!-- <h2>All things are difficult before they are easy.</h2> -->
    <div class="vue-typed-js">
      <vue-typed-js
        class="mao"
        :strings="[
          '这是我的博客<br/>一个正在努力的前端小白<br/>欢迎各位大佬来访',
          '这是我的博客<br/>一个正在努力的前端小白<br/>往后我会在这里记录我的学习过程<br/>',
        ]"
        :cursorChar="'☜'"
        :typeSpeed="100"
        :backSpeed="50"
        :autoInsertCss="true"
      >
        <h1 class="typing web-font"></h1>
      </vue-typed-js>
    </div>
    <banner-img></banner-img>
    <glowworm-tu class="glowworm-tu"></glowworm-tu>
  </div>
</template>

<script>
import BannerImg from "@/components/BannerTu/index.vue";
import HeaderTop from "@/components/HeaderTop/index.vue";
import GlowwormTu from "@/components/Glowworm/index.vue"
export default {

  data() {
    return {
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100vh", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
    };
  },
  components: {
    BannerImg,
    HeaderTop,
    GlowwormTu
  },
};
</script>

<style  lang="less" scoped>
.glowworm-tu {
  width: 10%;
  position: absolute;
  top: 9%;
  left: 28%;
}
.vue-typed-js {
  // margin-top: 11%;
  letter-spacing: 1px;
  cursor: pointer;
  margin: 0 auto;
}
.mao {
  margin:10% auto ;
  text-align: center;
  margin-left: 35%;
  position: relative;
  -webkit-background-clip: text;
  background-clip: text;
  background-image: linear-gradient(#816f6f, rgb(148, 119, 119));
  -webkit-text-fill-color: transparent;
  line-height: 50px;
}
</style>