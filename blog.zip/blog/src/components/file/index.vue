<template>
  <div>
    <el-card>
      <el-timeline>
        <el-timeline-item
          v-for="(activity, index) in activities"
          :key="index"
          :type="type"
          :color="color"
          :size="activity.size"
          :timestamp="activity.ctime | rTime"
        >
          <!-- :icon="icon" -->
          <div class="lan-color">
            <span class="lan">浏览量:{{ activity.watch }}</span>
            <p @click="title(activity.id)" class="title">
              {{ activity.title }}
            </p>
          </div>
        </el-timeline-item>
      </el-timeline>
      <h3 class="sum">博客共有:&nbsp;{{ sum }}&nbsp;&nbsp;篇</h3>
    </el-card>
  </div>
</template>

<script>
import { getArticle } from "@/api/article";
export default {
  data() {
    return {
      activities: [],
      size: "large",
      type: "primary",
      icon: "el-icon-more",
      color: "#0bbd87",
      sum: "",
    };
  },
  methods: {
    async getData() {
      let res = await getArticle({});
      // console.log(res.data.results);
      this.activities = res.data.results;
      this.sum = this.activities.length;
    },
    title(id) {
      this.$router.push({ path: `/read/${id}` });
    },
  },
  filters: {
    rTime(date) {
      var json_date = new Date(date).toJSON();
      return new Date(new Date(json_date) + 8 * 3600 * 1000)
        .toISOString()
        .replace(/T/g, " ")
        .replace(/\.[\d]{3}Z/, "");
    },
    month(date) {
      return date.slice(6, 7);
    },
    day(date) {
      return date.slice(8, 10);
    },
  },
  created() {
    this.getData();
  },
};
</script>

<style scoped>
.lan {
  position: absolute;
  right: 0;
}
.el-card {
  position: relative;
}
.el-card:hover {
  cursor: pointer;
}
.sum {
  position: absolute;
  top: 0;
  right: 0;
  padding: 20px;
  color: #0bbd87;
}
.el-timeline {
  width: 70%;
}
.lan-color:hover {
  color: red;
}
.title:hover {
  transform: scale(1.03);
  -webkit-transition: all .07s ease;
  -moz-transition: all .07s ease;
  -o-transition: all .07s ease;
}
</style>