<template>
  <div>
    <el-card class="box-card">
      <div class="el-card-top">
        <el-input
          v-model="form.smg"
          placeholder="请输入内容"
          @keyup.enter.native="ipt"
        >
        </el-input>
        <i class="el-icon-search"></i>
      </div>
      <div class="el-card-bottom">
        <el-tag
          v-for="item in items"
          :key="item.label"
          :type="item.type"
          effect="dark"
          title="双击"
          @click="add(item.label)"
        >
          {{ item.label }}
        </el-tag>
      </div>
    </el-card>
  </div>
</template>

<script>
import SwitchIndex from "@/views/switch/index.vue";
export default {
  components: {
    SwitchIndex,
  },
  data() {
    return {
      form: {
        smg: "",
      },
      items: [
        { type: "info", label: "Js" },
        { type: "", label: "Node" },
        { type: "success", label: "Vue" },
        { type: "danger", label: "Less" },
        { type: "info", label: "小程序" },
        { type: "warning", label: "css" },
        { type: "", label: "Express" },
        { type: "danger", label: "Sass" },
      ],
    };
  },
  methods: {
    add(label) {
      this.$EventBus.$emit('label',label)
      console.log(`label是传过去的值`,label);
      this.$router.push({
        path: "/label",
      });
    },
    ipt() {
      this.$router.push({
        path: "/Rarticle",
      });
    },
  },
};
</script>

<style lang="less" scoped>
.el-icon-search {
  font-size: 20px;
  position: absolute;
  left: 75%;
  top: 35%;
  font-weight: 700;
  color: #666;
}
.box-card {
  margin: 50px auto;
  width: 360px;
  height: 360px;
  background-color: #fff;
  border-radius: 15px;
  cursor: pointer;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  border: none;
  .el-card-top {
    background-image: linear-gradient(100deg, #fa709a, #fee140);
    height: 70px;
    width: 360px;
    border-top-left-radius: 15px;
    border-top-right-radius: 15px;
    position: absolute;
    top: 0;
    left: 0;
    box-shadow: 1px 2px 2px #999;
    /deep/ .el-input {
      width: 80%;
      left: 50%;
      top: 50%;
      position: absolute;
      transform: translate(-50%, -50%);
      border-radius: 10px !important;
    }
  }
  .el-card-bottom {
    position: absolute;
    height: 60%;
    width: 90%;
    left: 50%;
    top: 50%;
    margin-top: 30px;
    transform: translate(-50%, -50%);
  }
  .el-tag {
    margin: 20px;
  }
}
</style>