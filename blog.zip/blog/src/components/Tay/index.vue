<template>
  <div>
    <div class="box_right">
      <h4 class="el-icon-share lei">&nbsp;&nbsp;分类</h4>
      <div class="box_bottom">
        <div class="box_bottom_">
          <h3 class="web-font">生活</h3>
          <span class="el-icon-collection-tag"></span>
        </div>
        <div class="box_bottom_">
          <h3 class="web-font">日记</h3>
          <span class="el-icon-collection-tag"></span>
        </div>
        <div class="box_bottom_">
          <h3 class="web-font">学习笔记</h3>
          <span class="el-icon-collection-tag"></span>
        </div>
        <div class="box_bottom_">
          <h3 class="web-font">PHP</h3>
          <span class="el-icon-collection-tag"></span>
        </div>
        <div class="box_bottom_">
          <h3 class="web-font">项目经验</h3>
          <span class="el-icon-collection-tag"></span>
        </div>
        <div class="box_bottom_">
          <h3 class="web-font">情感</h3>
          <span class="el-icon-collection-tag"></span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.lei {
  width: 100%;
}
.box_right {
  margin: 50px auto;
  width: 360px;
  height: 360px;
  background-color: #fff;
  border-radius: 15px;
  cursor: pointer;
}
.box_bottom_ h3:hover {
  color: red;
}
h4 {
  width: 330px;
  height: 50px;
  line-height: 50px;
  padding-left: 30px;
  color: purple;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
  background: rgba(243, 244, 245, 0.8);
}
.el-icon-collection-tag {
  display: inline-block;
  transform: rotate(90deg);
  background-size: 50px 50px;
  color: purple;
  font-size: 27px;
  position: absolute;
  right: 10px;
  top: 10px;
}
.box_bottom_ {
  width: 310px;
  height: 40px;
  line-height: 40px;
  position: relative;
  border-radius: 5px;
}
h3 {
  padding-left: 10px;
  font-size: 16px;
  font-weight: 500;
  border-bottom: 1px solid rgba(0, 0, 0, 0.12);
}
.box_right:hover {
  box-shadow: 0px 0px 10px 2px rgb(238, 179, 223);
  transform: translate(0, -7px);
}
.box_bottom {
  /* border-top: 1px solid rgb(163, 157, 158); */
  height: 270px;
  margin: 20px auto;
  width: 330px;
  border-radius: 5px;
  border: 1px solid rgba(0, 0, 0, 0.12);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
}
</style>