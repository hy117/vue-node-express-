<template>
  <div>
    <el-card>
      <div class="header">
        <i class="el-icon-loading"></i>
        <h3>热门文章</h3>
      </div>
      <vue-seamless-scroll :data="listData" class="seamless-warp">
        <ul class="item">
          <li
            v-for="item in listData"
            class="article"
            @click="articles(item.id)"
          >
            <span class="title info-content">{{ item.title }}</span>
            <span class="date info-lan">浏览量:{{ item.watch }}</span>
          </li>
        </ul>
      </vue-seamless-scroll>
    </el-card>
  </div>
</template>

<script>
import { getArticle } from "@/api/article";
export default {
  data() {
    return {
      listData: [],
    };
  },
  methods: {
    async getArticle() {
      let res = await getArticle({});
      // console.log(res.data.results);
      this.listData = res.data.results;
    },
    articles(id) {
      this.$router.push({
        path: `/read/${id}`,
      });
      // console.log(id);
    },
  },
  created() {
    this.getArticle();
  },
};
</script>
<style  scoped>
.info-content {
  height: 40px;
  line-height: 40px;
  width: 75%; /*根据自己项目进行定义宽度*/
  overflow: hidden; /*设置超出的部分进行影藏*/
  text-overflow: ellipsis; /*设置超出部分使用省略号*/
  white-space: nowrap; /*设置为单行*/
}
.info-lan {
  height: 40px;
  line-height: 40px;
}
.article {
  display: flex;
  justify-content: space-between;
}
.article:hover {
  background-color: rgb(205, 122, 253);
  padding: 0 15px;
  color: white;
  cursor: pointer;
}
.header {
  display: flex;
  margin: 10px;
  color: purple;
  margin-bottom: 30px;
}
.header h3 {
  margin-left: 20px;
}
.seamless-warp {
  height: 229px;
  overflow: hidden;
}
.el-card {
  width: 360px;
  margin: 50px auto;
  border-radius: 20px;
}
.el-card:hover {
  box-shadow: 0px 0px 10px 2px rgb(187, 96, 240);
  transform: translate(0, -7px);
}
</style>