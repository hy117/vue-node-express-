<template>
  <div>
     <div class="Css_PM_Mark_Img" ></div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.Css_PM_Mark_Img{
width: 22px;
height: 22px;
border-radius: 11px;
animation: flicker 4000ms ease infinite;
}

/* 萤火虫特效 */
@keyframes flicker {
    0%, 100% {
        background: #fefa01;
        box-shadow: 0 0 1rem #fefa01;
    }
    30%, 70% {
        background: #fffd99;
        box-shadow: -1rem 0 8rem 1rem #fefa01;
    }
    50% {
        box-shadow: -1rem 0 8rem 1rem rgba(254, 250, 1, 0.8);
    }
}
</style>