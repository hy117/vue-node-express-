<template>
  <div class="discovery-container">
    <!-- 轮播图 -->
    <el-carousel class="" :interval="4000" type="card">
      <el-carousel-item v-for="(item, index) in banners" :key="index">
        <img :src="item.imageUrl" alt="" />
      </el-carousel-item>
    </el-carousel>
    <!-- 推荐歌单 -->
    <div class="recommend">
      <h3 class="title">推荐歌单</h3>
      <div class="items">
        <div class="item" v-for="(item, index) in playList" :key="item.id">
          <div class="img-wrap" @click="toPlayList(item.id)">
            <div class="desc-wrap">
              <span class="desc">{{ item.copywriter }}</span>
            </div>
            <img :src="item.picUrl" alt="" />
            <span class="iconfont icon-play"></span>
          </div>
          <p class="name">{{ item.name }}</p>
        </div>
      </div>
    </div>
    <!-- 最新音乐 -->
    <div class="news">
      <h3 class="title">最新音乐</h3>
      <div class="items">
        <div class="item" v-for="(item, index) in newsong" :key="index">
          <div class="img-wrap">
            <img :src="item.picUrl" alt="" />
            <span @click="playMusic(item.id)" class="iconfont icon-play"></span>
          </div>
          <div class="song-wrap">
            <div class="song-name">{{ item.name }}</div>
            <div class="singer">{{ item.song.artists[0].name }}</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 推荐MV -->
    <div class="mvs">
      <h3 class="title">推荐MV</h3>
      <div class="items">
        <div class="item" v-for="item in mv" :key="item.id">
          <div class="img-wrap" @click="toMv(item.id)">
            <img :src="item.picUrl" alt="" />
            <span class="iconfont icon-play"></span>
            <div class="num-wrap">
              <div class="iconfont icon-play"></div>
              <div class="num">{{ item.playCount }}</div>
            </div>
          </div>
          <div class="info-wrap">
            <div class="name">{{ item.copywriter }}</div>
            <div class="singer">{{ item.artistName }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { banner, songlist, newsong, mv, songUrl } from "@/api/discovery";
export default {
  name: "discovery",
  data() {
    return {
      // 轮播图
      banners: [],
      // 歌单
      playList: [],

      // 新歌
      newsong: [],
      // mv
      mv: [],
      // 歌曲url
      songUrl: "",
      musicT: "@/assets/images/music.jpg",
    };
  },
  created() {
    banner().then((res) => {
      this.banners = res.banners;
    });
    songlist().then((res) => {
      // window.console.log(res)
      this.playList = res.result;
      // console.log(res.result);
      (this.playList[1].picUrl =
        "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fc-ssl.duitang.com%2Fuploads%2Fitem%2F202003%2F23%2F20200323072124_8saQY.thumb.400_0.jpeg&refer=http%3A%2F%2Fc-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1649421770&t=fd5d674a1d371ae292498c3de3c6aada"),
        (this.playList[2].picUrl =
          "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fc-ssl.duitang.com%2Fuploads%2Fblog%2F202106%2F13%2F20210613174747_76390.thumb.1000_0.png&refer=http%3A%2F%2Fc-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1649421659&t=9a6cac4c050557d0630978b31260e273"),
        (this.playList[3].picUrl =
          "https://img0.baidu.com/it/u=989987914,4140469584&fm=253&fmt=auto&app=138&f=JPEG?w=891&h=500"),
        (this.playList[7].picUrl =
          "https://img0.baidu.com/it/u=3216503156,3166399728&fm=253&fmt=auto&app=138&f=JPEG?w=700&h=379"),
        (this.playList[8].picUrl =
          "https://img2.baidu.com/it/u=3204577803,1426557832&fm=253&fmt=auto&app=138&f=JPEG?w=700&h=405"),
        (this.playList[9].picUrl =
          "https://img0.baidu.com/it/u=4275116141,799789674&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=297");
    });
    newsong().then((res) => {
      this.newsong = res.result;
    });
    mv().then((res) => {
      this.mv = res.result;
    });
  },
  mounted() {},
  methods: {
    toMv(id) {
      this.$router.push(`/mv?id=${id}`);
    },
    toPlayList(id) {
      this.$router.push(`/playlist?id=${id}`);
    },
    playMusic(id) {
      songUrl({
        id: id,
      }).then((res) => {
        // window.console.log(res)
        // this.songUrl = res.data[0].url
        this.$parent.url = res.data[0].url;
      });
    },
  },
};
</script>

<style lang="less">
.discovery-container {
  .el-carousel__container {
    height: 230px;
  }
  .el-carousel__item img {
    width: 100%;
    height: 100%;
    border-radius: 10px;
  }
  .title {
    font-weight: normal;
    margin-bottom: 20px;
    padding-left: 8px;
  }
  // 推荐音乐
  .recommend {
    margin-bottom: 40px;
    .items {
      display: flex;
      flex-wrap: wrap;
      .item {
        width: 200px;
        margin: 10px;
        position: relative;
        overflow: hidden;
        img {
          width: 200px;
          height: 200px;
          border-radius: 5px;
        }
        .desc-wrap {
          position: absolute;
          width: 100%;
          top: 0;
          left: 0;
          font-size: 16px;
          color: white;
          background: rgba(0, 0, 0, 0.5);
          max-height: 50px;
          padding: 5px;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          top: -50px;
          span {
            font-size: 14px;
          }
        }
        &:hover .desc-wrap {
          top: 0;
        }
        .img-wrap {
          position: relative;
          .icon-play {
            position: absolute;
            right: 10px;
            bottom: 13px;
            width: 40px;
            height: 40px;
            color: #dd6d60;
            font-size: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.8);
            opacity: 0;
            &::before {
              transform: translateX(3px);
            }
          }
          &:hover .icon-play {
            opacity: 1;
          }
        }
        .name {
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          font-size: 14px;
        }
      }
    }
  }
  // 最新音乐
  .news {
    margin-bottom: 40px;
    .items {
      height: 500px;
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      .item {
        height: 100px;
        width: 50%;
        display: flex;
        align-items: center;
        padding-left: 15px;
        &:hover {
          background-color: #f5f5f5;
        }
        .index {
          margin-right: 15px;
          font-size: 15px;
        }
        .img-wrap {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          img {
            width: 80px;
            height: 80px;
          }
          .iconfont {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 30px;
            height: 30px;
            color: #dd6d60;
            text-align: center;
            line-height: 30px;
            border-radius: 50%;
            font-size: 14px;
            background: rgba(255, 255, 255, 0.8);
            opacity: 0;
            &::before {
              transform: translateX(3px);
            }
          }
          &:hover .iconfont {
            opacity: 1;
          }
        }
        .song-wrap {
          display: flex;
          flex-direction: column;
          justify-content: space-around;
          height: 100%;
          padding: 10px;
          font-size: 16px;
          .song-name {
          }
          .singer {
            font-size: 14px;
            color: gray;
          }
        }
      }
    }
  }
  .mvs {
    .items {
      display: flex;
      justify-content: space-around;
      .item {
        width: 250px;
        cursor: pointer;
        .img-wrap {
          width: 100%;
          position: relative;
          > .icon-play {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 40px;
            height: 40px;
            color: #dd6d60;
            font-size: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.8);
            opacity: 0;
            &::before {
              transform: translateX(3px);
            }
          }
          &:hover > .icon-play {
            opacity: 1;
          }
          img {
            width: 100%;
            border-radius: 5px;
          }
          .num-wrap {
            position: absolute;
            color: white;
            top: 0;
            right: 0;
            display: flex;
            align-content: center;
            font-size: 15px;
            padding-right: 5px;
            padding-top: 2px;
            .icon-play {
              font-size: 12px;
              display: flex;
              align-items: center;
              margin-right: 5px;
            }
          }
        }
        .info-wrap {
          .name {
            font-size: 15px;
            margin-bottom: 5px;
          }
          .singer {
            font-size: 14px;
            color: #c5c5c5;
          }
        }
      }
    }
  }
}
</style>
