import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: () => import("@/views/layout/layout.vue"),
    redirect: 'index',
    children: [
      {
        path: '/index',
        component: () => import("@/views/main/main.vue")
      },
      {
        path: '/blog',
        component: () => import("@/views/article/blog.vue")
      },
    ]
  },
  //文章
  {
    path: '/article',
    component: () => import("@/views/article/index.vue"),
    redirect: '/Rarticle',
    children: [
      {
        path: '/Rarticle',
        component: () => import("@/views/Rarticle/index.vue")
      },
      {
        path: '/label',
        component: () => import("@/views/switch/index.vue")
      }
    ]
  },
  //音乐
  {
    path: '/main',
    component: () => import("@/views/discovery/main.vue"),
    redirect: '/discovery',
    children: [
      {
        // 发现音乐
        path: '/discovery',
        component: () => import("@/components/music/discovery.vue")
      },
      {
        // 推荐歌单
        path: '/playlists',
        component: () => import("@/components/music/playlists.vue")
      },
      {
        // 推荐歌单
        path: '/playlist',
        component: () => import("@/components/music/playlist.vue")
      },
      {
        // 最新音乐
        path: '/songs',
        component: () => import("@/components/music/songs.vue")
      },
      {
        // 最新音乐
        path: '/mvs',
        component: () => import("@/components/music/mvs.vue")
      },
      // mv详情
      {
        path: '/mv',
        component: () => import("@/components/music/mv.vue")
      },
      // 搜索结果页
      {
        path: '/result',
        component: () => import("@/components/music/result.vue")
      },
    ]
  },
  //留言
  {
    path: '/plate',
    component: () => import("@/views/plate/index.vue")
  },
  //归档
  {
    path: '/file',
    component: () => import("@/views/file/index.vue")
  },
  //关于我
  {
    path: '/about',
    component: () => import("@/views/about/index.vue")
  },
  //详情页
  {
    path: '/read/:id',
    component: () => import("@/views/read/index.vue")
  },
  {
    path:'/login',
    component: () => import('@/views/HomeLogin/index.vue')
  },
  {
    path:'/register',
    component: () => import('@/views/HomeRegister/index.vue')
  },
]

const router = new VueRouter({
  routes
})

export default router
