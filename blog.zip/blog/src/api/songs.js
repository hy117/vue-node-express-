import request from '@/utils/request2';
// mv地址
export function topSongs({type}) {
    return request({
      url: '/top/song',
      method: 'get',
      params:{
          type
      }
    });
  }
