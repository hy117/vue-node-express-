import request from '@/utils/request'

//获取所有文章
export const getArticle = (data) => {
  return request({
    method:'post',
    url:'/api/getArticle',
    data
  })
}
//获取文章列表
export const getArticleList = (data) => {
  return request({
    method:'post',
    url:'/api/getArticleList',
    data
  })
}
//获取当前id文章
export const getIdArticle = (data) => {
  return request({
    method:'post',
    url:'/api/getIdArticle',
    data
  })
}
//观看
export const see = (data) => {
  return request({
    method:'post',
    url:'/api/see',
    data
  })
}
//点赞
export const fabulous = (data) => {
  return request({
    method:'post',
    url:'/api/fabulous',
    data
  })
}
//标签
export const labels = (data) => {
  return request({
    method:'post',
    url:'api/label',
    data
  })
}