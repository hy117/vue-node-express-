import request from '@/utils/request'
//登录
export const login = (data) => {
  return request({
    method:'post',
    url:'/api/HomeLogin',
    data
  })
}
//注册
export const register = (data) => {
  return request({
    method:'post',
    url:'/api/HomeRegister',
    data
  })
}
//获取用户信息
export const userInfo = (data) => {
  return request({
    method:'post',
    url:'/api/userInfo',
    data
  })
}