import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import VueTypedJs from 'vue-typed-js'
import store from './store'//引入store
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import mavonEditor from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
Vue.use(mavonEditor)

import VueParticles from 'vue-particles'
Vue.use(VueParticles)

import scroll from 'vue-seamless-scroll'
Vue.use(scroll)


Vue.config.productionTip = false
Vue.use(ElementUI);

Vue.use(VueTypedJs)

//解决路由跳转原路由或者刷新出错
const originalReplace = VueRouter.prototype.replace;
VueRouter.prototype.replace = function replace(location) {
    return originalReplace.call(this, location).catch(err => err);
};
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
}

//载入字体图标 @代表src工程文件夹目录
import '@/assets/fonts/iconfont.css'

//事件总线
Vue.prototype.$EventBus = new Vue()
// const bus = new Vue()
// export { bus }


//默认样式
import "@/assets/css/reset.css"
//字体样式
import "@/assets/font/font.css"

//音乐
import moment from 'moment';
// 全局过滤器
Vue.filter('formatDuration',(dt)=>{
  // 转分
  let min = Math.ceil(dt / 1000 / 60);
  min = min < 10 ? '0' + min : min;
  // 秒
  let sec = Math.ceil((dt / 1000) % 60);
  sec = sec < 10 ? '0' + sec : sec;
  return min + ':' + sec;
})
Vue.filter('formatTime', (time)=>{
  return moment(time).format('YYYY-MM-DD hh:mm:ss');
})
Vue.filter('formatCount',(count)=>{
  if (count / 10000 > 10) {
    return parseInt(count / 10000) + '万';
  } else {
    return count;
  }
})





new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
