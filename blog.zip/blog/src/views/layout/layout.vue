<template>
  <div>
    <div class="layout"></div>
    <el-row>
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24">
        <div class="grid-content bg-purple">
          <header-bg></header-bg>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24" class="bg">
        <router-view></router-view>
      </el-col>
      <el-col>
        <layout-footer class="footer"></layout-footer>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import LayoutFooter from "@/components/Footer/index.vue";
import HeaderBg from "@/views/layout/home.vue";
export default {
  components: {
    LayoutFooter,
    HeaderBg,
  },
};
</script>

<style scoped>
.bg {
  background-color: #eaeaea;
}
</style>