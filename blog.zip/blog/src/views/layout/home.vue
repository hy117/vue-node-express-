<template>
  <div>
    <header-bg></header-bg>
  </div>
</template>

<script>
import HeaderBg from "@/components/Header/index.vue";
export default {
  components: {
    HeaderBg,
  },
  data() {
    return {

    };
  },
};
</script>

<style lang="less" scoped>
</style>