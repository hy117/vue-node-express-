<template>
  <div>
    <div class="blog-box">
      <transition-group appear tag="div">
        <div class="main-blog" v-for="(item, index) in articles" :key="item.id">
          <span class="blog-y">
            <h5>{{ item.ctime | month }}</h5>
            <h1>{{ item.ctime | day }}</h1>
          </span>
          <h2 class="web-font">{{ item.title }}</h2>
          <div class="main-blog-d">
            <div>
              <i class="el-icon-user-solid"></i>
              <span>发布于</span>
            </div>
            <div style="margin-top: 3px">
              <i class="el-icon-alarm-clock"></i>
              <span class="time">{{ item.ctime | rTime }}</span>
            </div>
            <div>
              <i class="icon el-icon-view"></i>
              <span style="margin: 0 2px">{{ item.watch }}</span>
              <span>观看</span>
            </div>
            <div style="margin-left: 10px" class="fabulous">
              <i class="icon el-icon-magic-stick"></i>
              <span ref="fabulous" class="fabulous-yang">{{
                item.fabulous
              }}</span>
              <span @click="clicKFabulous(item.id, item.fabulous, index)"
                >点赞</span
              >
            </div>
          </div>
          <p class="blog-text web-font">{{ item.introduce }}</p>
          <hr />
          <el-tag class="tag" :key="item.label" type="success" effect="dark">
            {{ item.label }}
          </el-tag>
          <div class="Yue-btn">
            <el-button type="primary" @click="details(item.id, item.watch)"
              >阅读全文>></el-button
            >
          </div>
        </div>
      </transition-group>
      <div class="paging">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[3, 5]"
          :page-size="100"
          layout="total, sizes, prev, pager, next"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import {
  getArticle,
  getArticleList,
  see,
  fabulous,
  labels,
} from "@/api/article";
// import TabIndex from "@/components/Tab/index.vue";
export default {
  name: "labelY",
  // components: {
  //   TabIndex,
  // },
  data() {
    return {
      articles: [],
      //当前页
      currentPage: 1,
      //每页几条
      pageSize: 3,
      //总条数
      total: 0,
      id: "",
      match: "",
      day: "",
      label: "",
      abcd: "",
    };
  },
  filters: {
    rTime(date) {
      var json_date = new Date(date).toJSON();
      return new Date(new Date(json_date) + 8 * 3600 * 1000)
        .toISOString()
        .replace(/T/g, " ")
        .replace(/\.[\d]{3}Z/, "");
    },
    month(date) {
      return date.slice(6, 7);
    },
    day(date) {
      return date.slice(8, 10);
    },
  },
  watch: {
    clicKFabulous(id, zan) {},
  },
  methods: {
    async details(id, watch) {
      this.$router.push({ path: `/read/${id}` });
      // this.see++;
      // console.log(this.see);
      let res = await see({
        id: id,
        see: watch,
      });
    },
    async clicKFabulous(id, zan, index) {
      let res = await fabulous({
        id: id,
        fabulous: zan,
      });
      this.articles[index].fabulous++;
      // console.log(this.articles[index]);
      // this.$router.go(0)
      // window.location.reload();
      // this.$forceUpdate();
      // if ( window.location.reload()) {
      //   console.log('1');
      // }
    },
    async getData(label) {
      let res = await labels({
        currentPage: this.currentPage,
        pageSize: this.pageSize,
        label: label,
      });
      // console.log(res.data);
      // console.log(this.abcd);
      this.total = res.data.total;
      this.articles = res.data.data;
      // console.log(this.articles[0]);
      let articles = res.data.total;
      // console.log(this.articles);
      // console.log(articles);
      if (this.currentPage !== 1 && this.articles.length === 0) {
        //页码-1
        this.currentPage -= 1;
        //拉取数据
        this.getData();
      }
    },
    //改变页码触发
    handleSizeChange(val) {
      //把val 赋值给 pageSize
      this.pageSize = val;
      //拉取数据
      this.getData();
    },
    //当前页改变触发
    handleCurrentChange(val) {
      //当前页 赋值给 currentPage
      this.currentPage = val;
      //拉去数据
      this.getData();
    },
  },
  created() {
    this.$EventBus.$on("label", (label) => {
      // console.log(`我是data里面的值,给后端的`,abcd);
      this.getData(label);
    });
    // console.log(`我是接收的值`, label);
    // this.getData();
    // abcd = label;
    // console.log(`this.abcd-------`,abcd);

    // console.log(`label`,label);
  },
  mounted() {},
};
</script>

<style  lang="less" scoped>
.tag {
  margin: 20px 50px;
}
.blog-box {
  .paging {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
  }
}
.fabulous {
  cursor: pointer;
}
.icon {
  font-weight: 600;
}
.blog-text {
  font-size: 17px;
}
.main-blog:hover {
  box-shadow: 0px 0px 10px 2px rgba(245, 248, 49, 0.5);
  transform: translate(-2%, -2%);
}
.main-blog {
  background-color: white;
  border-radius: 5px;
  position: relative;
  margin-bottom: 50px;
  width: 83%;
  margin: 50px auto;
  hr {
    width: 90%;
    margin: 0 auto;
  }
  .el-button {
    background-color: #97dffd;
    border: none;
    margin: 20px auto;
    text-align: center;
  }
  .el-button:hover {
    background-color: rgb(63, 62, 62);
  }
  p {
    color: #adadad;
    margin: 50px;
  }
  .Yue-btn {
    text-align: center;
  }
  h2 {
    color: rgba(19, 20, 19, 0.877);
    text-align: center;
    margin: 30px;
    padding-top: 30px;
  }
  .blog-y {
    width: 70px;
    height: 70px;
    display: inline-block;
    // border: 1px solid #4aa3fc;
    background-color: #97dffd;
    box-shadow: 0px 1px 1px 0.1px rgb(160, 160, 160);
    border-radius: 50%;
    position: absolute;
    left: -15px;
    top: -30px;
    h1,
    h5 {
      color: white;
      text-align: center;
      margin-top: 5px;
    }
    h1 {
      margin: -15px 0;
      font-size: 28px;
    }
    h5 {
      margin: 10px 0;
      font-size: 20px;
    }
  }
  .main-blog-d {
    display: flex;
    justify-content: center;
    padding-right: 20px;
    align-items: center;
    span {
      color: rgba(19, 20, 19, 0.877);
      font-size: 16px;
    }
    .time {
      font-size: 15px;
      margin-right: 20px;
    }
    i {
      color: rgba(19, 20, 19, 0.877);
      // margin: 5px;
    }
  }
}
.v-enter,
.v-leave-to {
  opacity: 0;
  transform: translateY(80px);
}

.v-enter-active,
.v-leave-active {
  transition: all 0.6s ease;
}

/* 下面的 .v-move 和 .v-leave-active 配合使用，能够实现列表后续的元素，渐渐地漂上来的效果 */

.v-move {
  transition: all 0.6s ease;
}

.v-leave-active {
  position: absolute;
}
</style>