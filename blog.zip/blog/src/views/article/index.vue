<template>
  <div>
    <el-row>
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24" :style="bgImg" class="header-top">
        <header-top></header-top>
      </el-col>
      <el-col>
        <el-row>
          <el-col :xs="24" :sm="24" :md="16" :lg="17" :xl="17">
            <router-view></router-view>
          </el-col>
          <el-col :xs="24" :sm="6" :md="8" :lg="7" :xl="7">
            <article-tay></article-tay>
            <tab-article></tab-article>
          </el-col>
        </el-row>
      </el-col>
      <el-col>
        <footer-bt class="footer"></footer-bt>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import HeaderTop from "@/components/HeaderTop/index.vue";
import FooterBt from "@/components/Footer/index.vue";
import ArticleBlog from "@/views/article/blog.vue";
import ArticleTay from "@/components/Tay/index.vue";
import TabArticle from "@/components/Tab/index.vue";
export default {
  data() {
    return {
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100%", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
    };
  },
  components: {
    HeaderTop,
    FooterBt,
    ArticleBlog,
    ArticleTay,
    TabArticle,
  },
};
</script>

<style scoped>
.header-top {
  z-index: 99;
  position: sticky;
  top: 0;
}
.el-row:nth-child(1) {
  background-color: #eaeaea;
}
/* .el-row:nth-child(2) .el-col:nth-child(1) {
  border: 1px solid red;
}
.el-row:nth-child(2) .el-col:nth-child(2) {
  border: 1px solid red;
} */
</style>