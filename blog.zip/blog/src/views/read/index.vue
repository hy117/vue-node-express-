<template>
  <div>
    <!-- <div class="box"> -->
    <!-- {{ this.$route.params.id }} -->
    <!-- <dynamic-bg class="bg"></dynamic-bg> -->
    <el-row>
      <el-col
        :xs="24"
        :sm="24"
        :md="24"
        :lg="24"
        :xl="24"
        :style="bgImg"
        class="header-top"
      >
        <header-top class="header-top"></header-top>
      </el-col>
      <el-col>
        <el-row class="el-row-two">
          <el-col :xs="24" :sm="24" :md="16" :lg="15" :xl="15" :push="1">
            <mavon-editor
              class="markdown-body"
              codeStyle="monokai"
              v-html="demo"
            ></mavon-editor>
          </el-col>
          <el-col :xs="24" :sm="6" :md="8" :lg="9" :xl="7" :push="1">
            <article-tab></article-tab>
          </el-col>
        </el-row>
      </el-col>
      <el-col>
        <footer-bt class="footer"></footer-bt>
      </el-col>
    </el-row>
  </div>
</template>


<script>
import marked from "marked";
import DynamicBg from "@/components/Dynamic";
import FooterBt from "@/components/Footer/index.vue";
import HeaderTop from "@/components/HeaderTop/index.vue";
import ArticleTab from "@/components/Tab/index.vue";
// import bg from "@/components/Dynamic";
import { getIdArticle } from "@/api/article";
export default {
  components: {
    DynamicBg,
    FooterBt,
    HeaderTop,
    ArticleTab,

  },
  data() {
    return {
      demo: "",
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100%", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
    };
  },
  methods: {
    async getData() {
      let res = await getIdArticle({
        id: this.$route.params.id,
      });
      let demo = res.data.results[0].content;
      this.demo = demo;
      this.codeData = demo;
      // console.log(demo);
    },
  },

  created() {
    this.getData();
  },
};
</script>

<style scoped>
/* .el-row-two .el-col:nth-child(1) {
  border: 1px solid red;
}
.el-row-two .el-col:nth-child(2) {
  border: 1px solid red;
} */
.el-row {
  /* border: 1px solid red; */
}
.header-top {
  z-index: 99999;
  position: sticky;
  top: 0;
}
.el-row:nth-child(1) {
  background-color: #eaeaea;
}
.footer {
  /* position: fixed; */
  /* bottom: 0; */
  width: 100%;
}
.markdown-body {
  /* background-color: #eaeaea; */
  /* width: 50%; */
  /* margin-left: 10%; */
  box-sizing: border-box;
  padding: 10px;
  margin: 50px;
  /* left: 20%; */
}
.markdown-body {
  padding: 30px;
}
.hljs {
  font-size: 15px;
}
.info {
  border-radius: 10px;
  line-height: 20px;
  padding: 10px;
  margin: 10px;
  background-color: #ffffff;
}
</style>