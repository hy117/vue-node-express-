<template>
  <div class="main">
    <!-- <header-top class="header-top"></header-top> -->
    <top />
    <index />
  </div>
</template>

<script>
// import HeaderTop from "@/components/HeaderTop/index.vue"
import top from '@/views/discovery/index.vue';
import index from '@/views/discovery/top.vue';
export default {
  components: {
    top,
    index,

  }
};
</script>

<style lang="less">
.main {
  height: 100%;
  .top-container {
    height: 60px;
    position: fixed;
    width: 100%;
    top: 0;
    left: 0;
  }
  .index-container {
    height: 100%;
    padding-top: 60px;
    padding-bottom: 60px;
  }
}
// .header-top {
//   background-color: red;
// }
</style>
