<template>
  <div>
    <el-row class="el-row-main">
      <el-col :xs="24" :sm="18" :md="18" :lg="17" :xl="18">
        <article-blog></article-blog>
      </el-col>
      <el-col :xs="24" :sm="6" :md="6" :lg="7" :xl="6">
        <home-notice></home-notice>
        <article-tay></article-tay>
        <scroll-article class="Scroll"></scroll-article>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import HomeNotice from "@/components/Notice/index.vue"
import ArticleBlog from "@/views/article/blog.vue";
import ArticleTay from "@/components/Tay/index.vue";
import ScrollArticle from "@/components/seamless/index.vue";
export default {
  components: {
    ArticleBlog,
    ArticleTay,
    ScrollArticle,
    HomeNotice
  },
};
</script>

<style scoped>
.el-col:nth-child(1) {
  margin: 0 auto;
}
</style>