<template>
  <div class="main">
    <el-row>
      <el-col :xs="24" :sm="15" :md="15" :lg="14" :xl="15">
        <div class="grid-content bg-purple article-blog">
              <article-blog></article-blog>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import ArticleBlog from "@/views/article/blog.vue";

export default {
  components: {
    ArticleBlog,
    
  },
};
</script>

<style scoped>

</style>