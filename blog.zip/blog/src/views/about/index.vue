<template>
  <div>
    <el-row>
      <el-col
        :xs="24"
        :sm="24"
        :md="24"
        :lg="24"
        :xl="24"
        :style="bgImg"
        class="header-top"
      >
        <header-top></header-top>
      </el-col>
      <el-col>
        <el-row>
          <el-col :xs="24" :sm="24" :md="16" :lg="17" :xl="17">
            <el-card>
              <h2>关于我</h2>
              <img src="@/assets/images/about.jpg" alt="" />
              <ul>
                <li><span class="el-icon-location"></span>武汉船舶职业技术学院--20级计算机应用</li>
                <li>未来希望成为一名优秀的前端程序🐵</li>
                <li>今后我会在这里记录我的学习过程</li>
                <li>未来可欺，干巴碟</li>
                <img src="@/assets/images/bao2.jpg" alt="" />
              </ul>
            </el-card>
            <el-card>
              <h2>关于博客</h2>
              <ul style="margin-top:30px">
                <li>博客前端技术：vue-router+vuex+Axios+ElementUi+Es6</li>
                <li>后台管理技术：vue-router+Axios+ElementUi+Es6</li>
                <li>！服务端技术：node+express+mysql</li>
                <li>本人还只是一个菜鸟，博客功能并不丰富,目前也仅支持pc端,在今后的学习中我会慢慢改进！</li>
              </ul>
            </el-card>
          </el-col>
        </el-row>
      </el-col>
      <el-col>
        <footer-bt class="footer"></footer-bt>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import HeaderTop from "@/components/HeaderTop/index.vue";
import FooterBt from "@/components/Footer/index.vue";
export default {
  data() {
    return {
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100%", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
    };
  },
  components: {
    HeaderTop,
    FooterBt,
  },
};
</script>

<style scoped>
.el-card {
  margin: 50px;
  margin-left: 20%;
  width: 100%;
}
.el-card:nth-child(1) ul,
.el-card:nth-child(2) ul {
  list-style-type: disc;
  color: rgb(80, 75, 75);
  margin-left: 10%;
}
.el-card:nth-child(1) ul li,
.el-card:nth-child(2) ul li {
  margin-bottom: 20px;
}
.el-card:nth-child(1) h2,
.el-card:nth-child(2) h2 {
  text-align: center;
  color: rgb(73, 64, 64);
}
.el-card:nth-child(1) img {
  margin: 20px auto;
  margin-left: 12%;
}
.header-top {
  z-index: 99;
  position: sticky;
  top: 0;
}
.el-row:nth-child(1) {
  background-color: #eaeaea;
}
.footer {
  /* position: absolute; */
  bottom: 0;
}
</style>