<template>
  <div>
    <el-row>
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24" :style="bgImg" class="header-top">
        <header-top></header-top>
      </el-col>
      <el-col>
         <file-g class="file-g"></file-g>
      </el-col>
      <el-col>
        <footer-bt class="footer"></footer-bt>
      </el-col>
    </el-row>
  </div>
</template>

<script>

import HeaderTop from "@/components/HeaderTop/index.vue";
import FooterBt from "@/components/Footer/index.vue";
import FileG from "@/components/file/index.vue"
export default {
  data() {
    return {
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100%", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
    };
  },
  components: {
    HeaderTop,
    FooterBt,
    FileG
  },

};
</script>

<style scoped>
.header-top {
  z-index: 99;
  position: sticky;
  top: 0;
}
.el-row:nth-child(1) {
  background-color: #eaeaea;
}
.file-g {
 width: 65%;
 margin: 50px auto;
}
</style>