<template>
  <div class="login-box">
    <div class="login">
      <!-- 登录表单 -->
      <div class="form">
        <div class="title">
          <!-- <img class="logo" src="../../assets/imgs/apple.png" alt="" /> -->
          <p class="text-p">博客注册</p>
        </div>
        <!-- 表单组件 -->
        <!-- size属性控制整个表单控件的大小 -->
        <!-- model属性绑定表单数据 -->
        <!-- rules表单验证规则 -->
        <!-- status-icon反馈验证图标 -->
        <el-form
          :rules="rules"
          ref="form"
          size="small"
          status-icon
          :model="formData"
        >
          <!-- 账号 -->
          <!-- prop验证字段 必须和表单数据一致 -->
          <el-form-item prop="username">
            <el-input
              prefix-icon="iconfont icon-account"
              type="text"
              v-model="formData.username"
              autocomplete="off"
              class="ipt"
              placeholder="请输入账号"
            ></el-input>
          </el-form-item>
          <!-- 密码 -->
          <el-form-item prop="password">
            <el-input
              v-model="formData.password"
              :type="isPwd ? 'password' : 'text'"
              autocomplete="off"
              class="ipt"
              placeholder="请输入密码"
            >
              <i slot="prefix" class="iconfont icon-lock"></i>
              <i
                v-if="isPwd"
                slot="suffix"
                @click="isPwd = !isPwd"
                class="iconfont icon-eye-close"
              ></i>
              <i
                v-else
                slot="suffix"
                @click="isPwd = !isPwd"
                class="iconfont icon-eye-open"
              ></i>
            </el-input>
          </el-form-item>
          <!-- 操作 -->
          <el-form-item>
            <el-button class="btn" @click="submit" type="primary"
              >注册</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
//引入工具函数
import { HomeUsername, HomePassword } from "@/utils/tool";

//引入对应的用户ajax模块函数
import { login, register } from "@/api/user";

export default {
  //数据
  data() {
    return {
      //表单数据
      formData: {
        username: "",
        password: "",
      },
      //表单验证规则对象
      rules: {
        username: [{ validator: HomeUsername, trigger: "blur" }],
        password: [{ validator: HomePassword, trigger: "blur" }],
      },
      //密码输入框状态
      isPwd: true,
    };
  },
  //函数
  methods: {
    //提交方法
    submit() {
      this.$refs.form.validate(async (valid) => {
        if (valid) {
          //发送请求
          let res = await register({ ...this.formData });
          //解构数据
          let { status, message } = res.data;

          //token鉴权 存入本地
          // window.localStorage.setItem("t_k", token);

          //如果code值为0 表示成功
          if (status === 0) {
            this.$message({
              message: message,
              type: "success",
            });
            //跳转到首页
            // this.$router.push('/home')
            this.$router.push({ path: "/login" });
          } else {
            this.$message.error(message);
            this.formData.username = "";
            this.formData.password = "";
          }
        } else {
          console.log("验证不通过！");
        }
      });
    },
  },
  created() {
    let that = this;
    document.onkeydown = function (e) {
      e = window.event || e;
      if (
        that.$route.path == "/login" &&
        (e.code == "Enter" || e.code == "enter")
      ) {
        //验证在登录界面和按得键是回车键enter
        that.submit("submit"); //登录函数
      }
    };
  },
};
</script>

<style lang="less" scoped>
.login {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 400px;
  background-color: white;
  left: 50%;
  top: 50%;
  position: absolute;
  transform: translate(-50%, -50%);
  height: 300px;
  border-radius: 20px;
}
.login-box {
  background: url("../../assets/images/bg.jpg") no-repeat center center;
  background-size: 100% 100%;
  height: 100vh;
}
.form {
  width: 300px;
  height: 240px;
  // background-color: wheat;
  .text-p {
    margin-bottom: 10px;
    color: #5d81b4;
  }
  .title {
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    letter-spacing: 2px;
    color: white;
  }
  .btn {
    width: 100%;
  }
  ::v-deep .el-input__inner {
    background: transparent;
    color: white;
  }
}
/deep/ .el-input__inner {
  color: #000 !important;
}
</style>