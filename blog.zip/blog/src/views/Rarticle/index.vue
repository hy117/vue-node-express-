<template>
  <div>
    <el-row>
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24">
        <article-blog></article-blog>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import HeaderTop from "@/components/HeaderTop/index.vue";
import FooterBt from "@/components/Footer/index.vue";
import ArticleBlog from "@/views/article/blog.vue";
import ArticleTay from "@/components/Tay/index.vue";
import TabArticle from "@/components/Tab/index.vue";
export default {
  data() {
    return {
      bgImg: {
        backgroundImage: "url(" + require("@/assets/images/bg.jpg") + ")",
        height: "100%", //这里一定要设置高度 否则背景图无法显示
        backgroundRepeat: "no-repeat",
      },
    };
  },
  components: {
    HeaderTop,
    FooterBt,
    ArticleBlog,
    ArticleTay,
    TabArticle,
  },
};
</script>

<style scoped>
.header-top {
  z-index: 99;
  position: sticky;
  top: 0;
}
.el-row:nth-child(1) {
  background-color: #eaeaea;
}
</style>