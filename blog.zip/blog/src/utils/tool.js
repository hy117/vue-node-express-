//验证用户名
export const HomeUsername = (rule, value, callback) => {
  //非空验证
  if (value === '') {
      callback(new Error('用户名不能为空！'))
  } else if (!/^[a-zA-Z0-9\u4e00-\u9fa5]{3,12}$/.test(value)) {
      callback(new Error('中文，数字，英文 3至12位'))
  } else {
      //验证成功必填
      callback()
  }
}
//验证密码
export const HomePassword = (rule, value, callback) => {
  //非空验证
  if (value === '') {
      callback(new Error('密码不能为空！'))
  } else if (!/^[a-zA-Z0-9_]{6,12}$/.test(value)) {
      callback(new Error('数字，英文，下划线 6至12位'))
  } else {
      //验证成功必填
      callback()
  }
}