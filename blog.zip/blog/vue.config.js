module.exports = { publicPath: process.env.NODE_ENV === 'production' ? './' : '/' }

const path = require('path')
function resolve(dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  configureWebpack: {
    resolve: {
      alias: {
        // eslint-disable-next-line no-undef
        '@': resolve('src'),
      },
    },
  },
}
module.exports = {
  css: {
    loaderOptions: {
      sass: {
        prependData: `@import "@/style/base.scss";`,
      },
    },
  },

}