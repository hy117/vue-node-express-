import Vue from 'vue'
import VueRouter from 'vue-router'

//阻止原地跳转的错误提示
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function (location) {
  return originalPush.call(this, location).catch(err => err)
}
//引入页面级别组件  首屏只加载必要的两个页面级别组件 登录&框架
import Login from '@/views/login/Login.vue'
import Layout from '@/views/layout/Layout.vue'

Vue.use(VueRouter)

const routes = [  //每一个配置对象代表一个一级路由
  /* 登录 */
  {
    path: '/login',
    component: Login
  },
  /* 后台首页 */
  {
    path: '/',
    meta: { path: '/home', title: '后台首页' },
    component: Layout, //首页的父级是框架组件
    redirect: '/home',
    children: [ //二级路由 儿子才是自己的组件
      {
        path: '/home',
        component: () => import('@/views/home/Home.vue') //懒加载 ：输入路由地址之后才加载
      }
    ]
  },
  /* 文章管理 */
  {
    path: '/article',
    component: Layout,
    redirect: '/article-list',
    meta: { path: '/article', title: '文章管理' },
    children: [
      {
        meta: { path: '/article-list', title: '文章列表' },
        path: '/article-list',
        component: () => import('@/views/article/ArticleList.vue')
      },
      {
        meta: { path: '/new-article', title: '新建文章' },
        path: '/new-article',
        component: () => import('@/views/article/NewArticle.vue')
      },
      {
        meta: { path: '/new-label', title: '新建标签' },
        path: '/new-label',
        component: () => import('@/views/article/NewBabel.vue')
      },
      {
        meta: { path: '/label-list', title: '标签列表' },
        path: '/label-list',
        component: () => import('@/views/article/BabelList.vue')
      },
    ]
  },
  /* 账号管理 */
  {
    path: '/account',
    component: Layout,
    meta: { path: '/account', title: '账号管理' },
    redirect: '/account/account-list',
    children: [
      {
        meta: { path: '/account/account-list', title: '账号列表' },
        path: '/account/account-list',
        component: () => import('@/views/account/AccountList.vue')
      },
      {
        meta: { path: '/account/account-add', title: '账号添加' },
        path: '/account/account-add',
        component: () => import('@/views/account/AccountAdd.vue')
      },
      {
        meta: { path: '/account/password-modify', title: '修改密码' },
        path: '/account/password-modify',
        component: () => import('@/views/account/PasswordModify.vue')
      },
      {
        meta: { path: '/account/person', title: '个人中心' },
        path: '/account/person',
        component: () => import('@/views/account/Person.vue')
      }
    ]
  },
]

const router = new VueRouter({
  routes
})

//路由全局前置守卫
router.beforeEach((to, from, next) => {
  //获取token
  const token = window.localStorage.getItem('t_k')
  if (token) {
    next()
  }else {
    if (to.path === '/login') {
      next()
    }else {
      next('/login')
    }
  }
//路由导航守卫无需再写这个方法
  // const token = localStorage.getItem('token');
  // if (!token) {
  //   this.$router.push({name: 'login'})
  // }
})

export default router
