/**
 * 工具函数
 */

/*
    rule 表示一个对象 里面有很多东西 rule可用可不用
    value 表单的值
    callback 回调函数 校验成功或失败 必填
    失败 callback(new Error('错误信息'))
    成功 callback()
*/
//验证用户名
export const checkAccount = (rule, value, callback) => {
    //非空验证
    if (value === '') {
        callback(new Error('用户名不能为空！'))
    } else if (!/^[a-zA-Z0-9\u4e00-\u9fa5]{3,12}$/.test(value)) {
        callback(new Error('中文，数字，英文 3至12位'))
    } else {
        //验证成功必填
        callback()
    }
}
//验证密码
export const checkPassword = (rule, value, callback) => {
    //非空验证
    if (value === '') {
        callback(new Error('密码不能为空！'))
    } else if (!/^[a-zA-Z0-9_]{6,12}$/.test(value)) {
        callback(new Error('数字，英文，下划线 6至12位'))
    } else {
        //验证成功必填
        callback()
    }
}
export const userGroup = (rule, value, callback) => {
    if (value == '') {
        callback(new Error('用户组不能为空！'))
    }else {
        callback()
    }
}
export const title = (rule, value, callback) => {
    if (value == '') {
        callback(new Error('标题不能为空！'))
    }else {
        callback()
    }
}
export const introduce = (rule, value, callback) => {
    if (value == '') {
        callback(new Error('文章简介不能为空'))
    }else {
        callback()
    }
}
export const content = (rule, value, callback) => {
    if (value == '') {
        callback(new Error('内容不能为空'))
    }else {
        callback()
    }
}
// export const label = (rule, value, callback) => {
//     if (value == '') {
//         callback(new Error('标签不能为空！'))
//     }else {
//         callback()
//     }
// }