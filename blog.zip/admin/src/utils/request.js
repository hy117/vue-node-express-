/**
 * ajax工具函数层
 */
import axios from 'axios'

axios.defaults.baseURL = 'http://localhost:3000' //默认服务器地址
axios.defaults.timeout = 10000;//配置超时时间10秒

//配置请求拦截器
axios.interceptors.request.use(config => {
    //取出token 鉴权。 token相当于人的身份证 一个角色的信息 权限全部存在这个加密的字符串里面
    let token = window.localStorage.getItem('t_k');
    if (token) {
        //只要有token 所有的接口请求都会携带这个token 发给后台【后台检查token 判断你是否有当前请求的权限】
        //authorization 字段是和后端商议的【当前项目叫authorization】
        config.headers.authorization = token;
    }
    return config
}, err => {
    return Promise.reject(err)
})

//配置响应拦截器
axios.interceptors.response.use(response => {
    return response
}, err => {
    return Promise.reject(err)
})

//暴露配置好的axios
export default axios