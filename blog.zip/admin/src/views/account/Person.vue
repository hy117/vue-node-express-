<template>
  <div class="person">
    <el-card>
      <div slot="header"><span>管理员信息</span></div>
      <div class="content">
        管理员ID：{{ form.id }}
        <el-divider></el-divider>
        用户名：{{ form.username }}
        <el-divider></el-divider>
        用户组：{{ form.userGroup }}
        <el-divider></el-divider>
        创建时间：{{ form.ctime }}
        <el-divider></el-divider>
        管理员头像
        <!-- action头像上传地址 -->
        <!-- show-file-list是否显示已上传文件列表 -->
        <!-- on-success文件上传成功时的钩子 -->
        <!-- before-upload上传文件之前的钩子 -->
        <!--   :action="API + '/users/avatar_upload'" -->
        <el-upload
          class="avatar-uploader"
          :action="API + '/my/update/avatar'"
          :show-file-list="false"
          :before-upload="beforeAvatarUpload"
          :on-success="handleAvatarSuccess"
        >
          <!-- :on-success="handleAvatarSuccess" -->
          <img v-if="form.image" :src="form.image" class="avatar" />
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
        <!-- @click="uploadImg" -->
        <el-button
          @click="uploadImg"
          class="btn-upload"
          size="small"
          type="primary"
          >确定上传</el-button
        >
      </div>
    </el-card>
  </div>
</template>

<script>
// 引入ajax函数
import { userInfoGe } from "@/api/user";
// import local from "../../utils/local";
export default {
  data() {
    return {
      API: "http://localhost:3000",
      //数据占位
      form: {
        username: "",
        ctime: "",
        id: "",
        image: "",
        userGroup: "",
      },
    };
  },
  //函数
  methods: {
    //上传成功触发
    async getData() {
      let res = await userInfoGe({});
      let userInfo = res.data;
      this.form.username = userInfo.data[0].username;
      this.form.ctime = userInfo.data[0].ctime;
      this.form.id = userInfo.data[0].id;
      this.form.image = userInfo.data[0].image;
      this.form.userGroup = userInfo.data[0].userGroup;
    },
    handleAvatarSuccess(res) {
      //res 后台返给前段的数据
      let { status, message, image } = res;
      if (status === 0) {
        this.$message({
          type: "success",
          message: message,
        });
        //处理格式 [返回的地址 后台决定，缺什么拼什么]
        this.form.image = this.API + image;
        console.log(res);
      } else {
        this.$message.error(message);
      }
    },
    beforeAvatarUpload(file) {
      const isJPG = /[jpeg|png]/.test(file.type);
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!');
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!');
      }
      return isJPG && isLt2M;
    },
    //上传头像到数据库
    async uploadImg() {
      //处理数据
      let temp = this.form.image;
      let image = temp.substr(temp.lastIndexOf("/") + 1);
      //上传
      let res = await editAvatar({ image });
      let { status, message } = res.data;
      //为0 表成功
      if (status === 0) {
        //中央事件总线 发送数据
        this.$bus.$emit("uploadImg");
      } else {
        this.$message.error(message);
      }
    },
  },
  //生命周期发送ajax
  created() {
    //拉取本地数据 赋值给form
    // this.form = local.get("userInfo");
    this.getData();
  },
};
</script>

<style lang="scss" scoped>
.btn-upload {
  margin-top: 20px;
}
.avatar-uploader {
  margin-top: 20px;
}
.avatar-uploader ::v-deep .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 90px;
  height: 90px;
  line-height: 90px;
  text-align: center;
}
.avatar {
  width: 90px;
  height: 90px;
  display: block;
}
</style>