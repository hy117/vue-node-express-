<template>
  <div>
    <ul>
      <li v-for="item in list" :key="item.id">
        <!-- {{ item.content }} -->
      </li>
      <div class="ueditor">
        <mavon-editor
          class="info"
          codeStyle="monokai"
          v-html="codeData2"
        ></mavon-editor>
        <br />
        <mavon-editor
          class="markdown-body"
          codeStyle="monokai"
          v-html="codeData3"
        ></mavon-editor>
        <br />
      </div>
    </ul>
  </div>
</template>

<script>
import { getArticle } from "@/api/article";
export default {
  data() {
    return {
      demo: "",
      list: [],
      codeData2: "",
      codeData3: "",
    };
  },
  methods: {
    async getArticle() {
      let res = await getArticle({});

      let { results, status } = res.data;
      this.list = results;
      this.codeData2 = results[10].content;
       this.codeData3 = results[9].content;
      // console.log(res.data.results[0]);
    },
  },
  created() {
    this.getArticle();
  },
};
</script>

<style  lang="scss" scoped>
.hljs {
  font-size: 15px;
}
.info {
  border-radius: 10px;
  line-height: 20px;
  padding: 10px;
  margin: 10px;
  background-color: #ffffff;
}
</style>