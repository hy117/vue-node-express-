<template>
  <div>
    新建标签
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>