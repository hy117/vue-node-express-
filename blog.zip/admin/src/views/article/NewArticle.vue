<template>
  <div>
    <!-- 卡片视图 -->
    <el-card :body-style="{ padding: '10px' }">
      <!-- 表单部分 -->
      <el-form ref="form" label-width="80px" :rules="rules" :model="article">
        <el-form-item label="文章标题">
          <el-input v-model="article.title" props="title"> </el-input>
        </el-form-item>

        <el-form-item label="文章简介">
          <el-input v-model="article.introduce" props="introduce"> </el-input>
        </el-form-item>
        <!-- 标签选择 -->
        <el-form-item label="所含标签" props="label">
          <el-select
            v-model="value"
            filterable
            placeholder="请选择"
            value-key="id"
            @change="currentSel"
          >
            <el-option
              v-for="item in options"
              :key="item.id"
              :label="item.label"
              :value="item"
            ></el-option>
          </el-select>
        </el-form-item>
        <!-- 封面上传 -->
        <!-- <el-form-item label="上传封面">
          <el-upload class="upload-demo" :action="uploadUrl" :on-success="afterUpload">
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item> -->
        <!-- Markdown 编写 -->

        <el-form-item props="content">
          <mavon-editor
            :codeStyle="codeStyle"
            :toolbars="toolbars"
            v-model="content"
            :ishljs="true"
            ref="md"
            @change="change"
          />
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            style="float: right; margin-top: 15px"
            @click="NewArticle"
            >保存</el-button
          >
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { Article, articleCs } from "@/api/article";
import { title, introduce, content } from "@/utils/tool";
import marked from "marked";
export default {
  props: {
    id: {},
  },
  data() {
    return {
      article: {
        title: "",
        introduce: "",
        content: "",
        label: "",
      },
      content: "这里是markdown编辑的内容",
      page_article: undefined,
      html_content: undefined,
      md_content: undefined,
      toolbars: {
        bold: true, // 粗体
        italic: true, // 斜体
        header: true, // 标题
        underline: true, // 下划线
        strikethrough: true, // 中划线
        mark: true, // 标记
        superscript: true, // 上角标
        subscript: true, // 下角标
        quote: true, // 引用
        ol: true, // 有序列表
        ul: true, // 无序列表
        link: true, // 链接
        imagelink: true, // 图片链接
        code: true, // code
        table: true, // 表格
        fullscreen: true, // 全屏编辑
        readmodel: true, // 沉浸式阅读
        htmlcode: true, // 展示html源码
        help: true, // 帮助
        undo: true, // 上一步
        redo: true, // 下一步
        trash: true, // 清空
        save: true, // 保存（触发events中的save事件）
        navigation: true, // 导航目录
        alignleft: true, // 左对齐
        aligncenter: true, // 居中
        alignright: true, // 右对齐
        subfield: true, // 单双栏模式
        preview: true, // 预览
      },
      codeStyle: "monokai-sublime", //主题
      test_html: undefined,
      options: [
        {
          value: "选项1",
          id: 1,
          code: "xuanxiang1",
          label: "Vue",
        },
        {
          value: "选项2",
          id: 2,
          code: "xuanxiang2",
          label: "node",
        },
        {
          value: "选项3",
          id: 3,
          code: "xuanxiang3",
          label: "express",
        },
        {
          value: "选项4",
          id: 4,
          code: "xuanxiang3",
          label: "Js",
        },
        {
          value: "选项5",
          id: 5,
          code: "xuanxiang3",
          label: "Css",
        },
        {
          value: "选项6",
          id: 6,
          code: "xuanxiang3",
          label: "小程序",
        },
        {
          value: "选项7",
          id: 7,
          code: "xuanxiang3",
          label: "Less",
        },
        {
          value: "选项8",
          id: 8,
          code: "xuanxiang3",
          label: "Sass",
        },
      ],
      value: "",
      rules: {
        title: [{ validator: title, trigger: "blur" }],
        introduce: [{ validator: introduce, trigger: "blur" }],
        content: [{ validator: content, trigger: "blur" }],
        label: [{ required: true, message: "请选择标签", trigger: "blur" }],
      },
    };
  },
  methods: {
    NewArticle() {
      this.$refs.form.validate(async (valid) => {
        if (valid) {
          let res = await Article({
            title: this.article.title,
            introduce: this.article.introduce,
            content: this.test_html,
            label: this.article.label,
          });
          console.log(this.test_html);
          // let resA = await Article({
          //   label: this.article.label,
          //   title: this.article.title,
          //   introduce: this.article.introduce,
          // });

          let { status, message } = res.data;
          if (status === 0) {
            this.$notify({
              title: "成功",
              message: "文章创建成功",
              type: "success",
            });
            this.$router.push("/article-list");
            this.article.title = "";
            this.article.introduce = "";
            this.test_html = "";
            this.article.label = "";
          }
          if (status === 1) {
            this.$notify.error({
              title: "错误",
              message: "文章创建失败",
            });
          }
        } else {
          console.log("验证不通过！");
        }
      });
    },
    currentSel(selVal) {
      this.code = selVal.code;
      this.article.label = selVal.label;
    },
    change(value, render) {
      // render 为 markdown 解析后的结果
      // console.log(`value`, value);
      // console.log(`render`, render);

      this.test_html = render;
    },
  },
};
</script>
