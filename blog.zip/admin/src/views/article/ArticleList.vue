<template>
  <el-card class="account-list">
    <div slot="header"><span>文章列表</span></div>
    <div class="content">
      <!-- 表格 -->
      <!-- data绑定数据 -->
      <el-table
        @selection-change="handleSelChange"
        :data="tableData"
        ref="table"
        :style="{ width: w + 'px' }"
      >
        <el-table-column type="selection" width="55"> </el-table-column>
        <!-- 文章标题 -->
        <el-table-column label="Id" prop="id"></el-table-column>
        <!-- prop 对应列内容的字段名 -->
        <el-table-column label="文章标题" prop="title"> </el-table-column>
        <!-- 标签类别 -->
        <el-table-column label="标签类别" prop="label"> </el-table-column>
        <!-- 日期 -->
        <el-table-column label="日期">
          <!-- 作用域插槽  -->
          <template slot-scope="scope">
            <span>{{ date }}</span>
          </template>
        </el-table-column>
        <!-- 操作 -->
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button
              class="btn-edit"
              size="mini"
              @click="
                handleEdit(scope.row);
                dialogFormVisible = true;
              "
              >编辑</el-button
            >
            <el-popconfirm
              @confirm="handleDelete(scope.row)"
              @cancel="$message({ type: 'info', message: '取消删除' })"
              title="这是一段内容确定删除吗？"
            >
              <el-button slot="reference" size="mini" type="danger"
                >删除</el-button
              >
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <!-- background 背景色  -->
      <!-- page-size显示条目数 -->
      <!-- total总页数 -->
      <!-- current-page当前页数 -->
      <!-- page-sizes显示每页多少条选项 -->
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[3, 5]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        class="pagination"
      >
      </el-pagination>
      <!-- 操作按钮 -->
      <div class="bottom-box">
        <el-button type="danger" @click="handleBatchDel" size="small"
          >批量删除</el-button
        >
        <el-button type="primary" @click="handleCancelSel" size="small"
          >取消选择</el-button
        >
      </div>
    </div>

    <!-- 编辑文章 -->
    <el-dialog title="编辑文章" :visible.sync="dialogFormVisible">
      <el-form size="small" :model="article" label-width="100px">
        <!-- 标题 -->
        <el-form-item label="标题">
          <el-input v-model="article.title" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="所含标签" props="label">
          <el-select
            v-model="value"
            filterable
            placeholder="请选择"
            value-key="id"
            @change="currentSel"
          >
            <el-option
              v-for="item in options"
              :key="item.id"
              :label="item.label"
              :value="item"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="dialogFormVisible = false"
          >取 消</el-button
        >
        <el-button size="small" type="primary" @click="handleEditConfirm"
          >确 定</el-button
        >
      </div>
    </el-dialog>
  </el-card>
</template>

<script>
//引入接口管理层的user模块 对应的ajax接口函数
import {
  getFeedArticles,
  deleteArticle,
  moveArticle,
  editArticle,
} from "@/api/article";
// import { normalizeYmd } from "@/utils/tool";
export default {
  //数据
  data() {
    return {
      value: "",
      options: [
        {
          value: "选项1",
          id: 1,
          code: "xuanxiang1",
          label: "vue",
        },
        {
          value: "选项2",
          id: 2,
          code: "xuanxiang2",
          label: "node",
        },
        {
          value: "选项3",
          id: 3,
          code: "xuanxiang3",
          label: "express",
        },
      ],
      //时间
      ctime: "",
      //表格数据
      tableData: [],
      //当前页
      currentPage: 1,
      //每页几条
      pageSize: 3,
      //总条数
      total: 0,
      //弹窗表单数据
      article: {
        id: "",
        title: "",
        label: "",
      },
      //编辑弹出显示
      dialogFormVisible: false,
      //table宽度
      w: 0,
      date:''
    };
  },
  //函数
  methods: {
    //获取数据
    async getFeedArticles() {
      let res = await getFeedArticles({
        currentPage: this.currentPage,
        pageSize: this.pageSize,
      });
      //解构数据
      let { id, title, ctime, label, total, data } = res.data;
      console.log(res.data.data);
      this.ctime = res.data.data[0].ctime;
      function rTime(date) {
        var json_date = new Date(date).toJSON();
        return new Date(new Date(json_date) + 8 * 3600 * 1000)
          .toISOString()
          .replace(/T/g, " ")
          .replace(/\.[\d]{3}Z/, "");
      }
      let date = rTime(this.ctime);
      this.date = date;
      this.total = total;
      this.tableData = data;
      // console.log(this.tableData);
      //当前页不为1 拉取数据为空。  当前页码-1 再拉取数据
      if (this.currentPage !== 1 && this.tableData.length === 0) {
        //页码-1
        this.currentPage -= 1;
        //拉取数据
        this.getFeedArticles();
      }
    },
    //改变页码触发
    handleSizeChange(val) {
      //把val 赋值给 pageSize
      this.pageSize = val;
      //拉取数据
      this.getFeedArticles();
    },
    //当前页改变触发
    handleCurrentChange(val) {
      //当前页 赋值给 currentPage
      this.currentPage = val;
      //拉去数据
      this.getFeedArticles();
    },
    //编辑
    handleEdit(row) {
      //回填数据 数据脱绑
      this.article = { ...row };
    },
    currentSel(selVal) {
      this.status = selVal.status;
      this.article.label = selVal.label;
      // console.log(this.article.label);
    },
    //确定编辑
    async handleEditConfirm() {
      //解构需要的数据
      let { id, title, label } = { ...this.article };
      let res = await editArticle({ id, title, label });
      let { status, message } = res.data;
      //code为0表示成功
      if (status === 0) {
        this.$message({
          type: "success",
          message: message,
        });
        //关闭弹窗
        this.dialogFormVisible = false;
      } else {
        this.$message.error(message);
      }
    },
    //删除
    async handleDelete(row) {
      let res = await deleteArticle({ id: row.id });
      let { status, message } = res.data;
      //判断status
      if (status === 0) {
        //拉取数据
        this.getFeedArticles();
      }
      this.$message({
        type: "success",
        message: "删除成功",
      });
    },
    //多选框触发
    handleSelChange(val) {
      //处理数据
      this.ids = JSON.stringify(val.map((v) => v.id));
    },
    //取消选择
    handleCancelSel() {
      this.$refs.table.clearSelection();
      this.$message({
        type: "success",
        message: "取消成功",
      });
    },
    //批量删除
    handleBatchDel() {
      this.$confirm("您是否确认要批量删除这些用户吗？", "批量删除", {
        distinguishCancelAndClose: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      })
        .then(async () => {
          let res = await moveArticle({ id: this.article.id });
          let { status, message } = res.data;
          if (status === 0) {
            //拉取数据
            this.getFeedArticles();
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        })
        .catch((action) => {
          this.$message({
            type: "info",
            message:
              action === "cancel" ? "放弃保存并离开页面" : "停留在当前页面",
          });
        });
    },
    //设置table宽度
    setTableWidth() {
      this.w = document.body.clientWidth - 280;
    },
  },
  //生命周期created 获取ajax数据
  created() {
    //初始化获取数据
    this.getFeedArticles();
  },
  //生命周期mounted 操作dom
  mounted() {
    this.setTableWidth();
    window.addEventListener("resize", this.setTableWidth);
  },
  beforeDestroy() {
    //在销毁组件前  把window上挂着的方法也销毁掉
    window.removeEventListener("resize", this.setTableWidth);
  },
};
</script>

<style lang="scss" scoped>
.pagination {
  margin-top: 20px;
}
.bottom-box {
  margin-top: 20px;
}
::v-deep .el-dialog__body .el-input__inner {
  width: 215px;
}
.btn-edit {
  margin-right: 10px;
}
</style>