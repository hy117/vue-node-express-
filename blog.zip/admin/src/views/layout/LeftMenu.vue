<template>
  <div class="left-menu">
    <!-- logo -->
    <div class="logo">
      <img width="50" src="../../assets/imgs/logo.gif" alt="" />
      博客管理系统
    </div>
    <!-- text-color文字颜色 -->
    <!-- background-color背景色 -->
    <!-- default-active默认激活菜单 -->
    <!-- unique-opened 是否只保持一个子菜单的展开 -->
    <!-- router 以 index 作为 path 进行路由跳转 -->
    <el-menu
      text-color="#eeeeee"
      background-color="#304156"
      :default-active="$route.path"
      unique-opened
      router
      class="menu"
    >
      <!--后台首页  -->
      <el-menu-item index="/home">
        <i class="iconfont icon-home"></i>
        <span slot="title">后台首页</span>
      </el-menu-item>
      <!-- 文章管理 -->
      <el-submenu index="/article">
        <template slot="title">
          <i class="iconfont icon-goods"></i>
          <span>文章管理</span>
        </template>
        <el-menu-item index="/article-list">文章列表</el-menu-item>
        <el-menu-item index="/new-article">新建文章</el-menu-item>
        <el-menu-item index="/new-label">新建标签</el-menu-item>
        <el-menu-item index="/label-list">标签列表</el-menu-item>
      </el-submenu>
      <!-- 账号管理 -->
      <el-submenu index="2">
        <template slot="title">
          <i class="iconfont icon-account"></i>
          <span>账号管理</span>
        </template>
        <el-menu-item index="/account/account-list">账号列表</el-menu-item>
        <el-menu-item index="/account/account-add">账号添加</el-menu-item>
        <el-menu-item index="/account/password-modify">修改密码</el-menu-item>
        <el-menu-item index="/account/person">个人中心</el-menu-item>
      </el-submenu>
    </el-menu>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.left-menu {
  background-color: $bg;
}
.el-menu {
  border-right: none;
}
.menu {
  width: 200px;
}
.logo {
  display: flex;
  height: 60px;
  padding-left: 10px;
  align-items: center;
  color: white;
  font-weight: 500;
  img {
    margin-right: 5px;
  }
}
.iconfont {
  margin-right: 5px;
}
// ::v-deep 可以穿透子组件的scoped属性 这是scss写法. less 是/deep/
.el-submenu {
  ::v-deep .el-menu--inline {
    .el-menu-item {
      background: darken($bg, 5%) !important;
      &:hover {
        background: darken($bg, 10%) !important;
      }
    }
  }
}
</style>