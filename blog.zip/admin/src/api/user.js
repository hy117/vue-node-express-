/**
 * 用户接口模块
 */

import request from '@/utils/request'

/* 登录接口 */
export const checkLogin = (data) => {
    return request({
        method: 'post',
        url: '/api/login',
        data
    })
}

/* 添加账号 */
export const addUser = (data) => {
    return request({
        method: 'post',
        url: '/api/userAdd',
        data
    })
}
export const addregister = (data) => {
    return request({
        method: 'post',
        url: '/api/register',
        data
    })
}
/* 获取用户列表 */
export const getUserList = (params) => {
    return request({
        method: 'get',
        url: '/my/userInfo',
        params
    })
}

/* 删除账号 */
export const deleteUser = (params) => {
    return request({
        method: 'get',
        url: '/my/deleteUser',
        params
    })
}
/* 编辑账号 */
export const editUser = (data) => {
    return request({
        method: 'post',
        url: '/my/edit',
        data
    })
}

/* 批量删除账号 */
export const deleteBatchUser = (params) => {
    return request({
        method: 'get',
        url: '/my/moveDelete',
        params
    })
}
//修改密码
export const updatePassword = (data) => {
    return request({
        method:'post',
        url:'my/updatePassword',
        data
    })
} 

/* 修改用户头像 */
export const editAvatar = (data) => {
    return request({
        method: 'post',
        url: '/my/update/avatar',
        data
    })
}
//个人信息
export const userInfoGe = (data) => {
    return request({
        method:'post',
        url:'my/userInfoGe',
        data
    })
}