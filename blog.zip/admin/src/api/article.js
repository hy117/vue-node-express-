/**
 * 文章管理
 */

import request from '@/utils/request'
//创建文章
export const Article = (data) => {
  return request({
    method:'post',
    url:'/api/createArticle',
    data
  })
}
//文章单独接口
export const articleCs = (data) => {
  return request({
    method:'post',
    url:'/api/articleCs',
    data
  })
}
//文章列表
export const getFeedArticles = (data) => {
  return request({
    method:'post',
    url:'/api/getFeedArticles',
    data
  })
}
/* 删除账号 */
export const deleteArticle = (data) => {
  return request({
      method: 'post',
      url: '/api/deleteArticle',
      data
  })
}
/* 编辑账号 */
export const editArticle = (data) => {
  return request({
      method: 'post',
      url: '/api/editArticle',
      data
  })
}

/* 批量删除账号 */
export const moveArticle = (data) => {
  return request({
      method: 'post',
      url: '/api/moveArticle',
      data
  })
}
//获取所有文章
export const getArticle = (data) => {
  return request({
    method:'post',
    url:'/api/getArticle',
    data
  })
}