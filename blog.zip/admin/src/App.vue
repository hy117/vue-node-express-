<template>
  <div class="app">
    <!-- 一级路由出口 跟组件App.vue -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss"  scoped>
.app {
  height: 100%;
}
</style>