module.exports = {
  css: { 
    loaderOptions: {
      sass: {
        prependData: `@import "@/assets/scss/_setting.scss";@import "~@/assets/scss/_mixin.scss";`,
      },
    },
  },
}