const conn = require('../db/request')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const config = require('../config/config')
const ctime = require('../util/time')
//注册register
exports.register = (req, res) => {
  // 接收表单数据
  const userInfo = req.body
  // const ctime = ctime()

  const sql = `select * from users where username=?`
  conn.query(sql, [userInfo.username], function (err, results) {
    // 执行 SQL 语句失败
    if (err) {
      return res.cc(err)
    }
    // 用户名被占用
    if (results.length > 0) {
      return res.cc('用户名被占用,请更换其他用户名!')
    }
    userInfo.password = bcrypt.hashSync(userInfo.password, 10)
    const sql = 'insert into users set ?'
    conn.query(sql, { ctime:ctime(), username: userInfo.username, password: userInfo.password }, function (err, results) {
      // 执行 SQL 语句失败
      if (err) return res.cc(err)
      // SQL 语句执行成功，但影响行数不为 1
      if (results.affectedRows !== 1) {
        return res.cc('注册用户失败，请稍后再试！')
      }
      // 注册成功
      res.cc('注册成功！', 0)
    })
  })
}
// 登录的处理函数
exports.login = (req, res) => {
  // 接收表单的数据
  const userInfo = req.body
  console.log(userInfo);
  // console.log('时间是',ctime());
  // const ctime = ctime()
  // console.log(ctime);
  // 定义 SQL 语句
  const sql = `select * from users where username=?`
  // 执行 SQL 语句，根据用户名查询用户的信息
  conn.query(sql, userInfo.username, (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 执行 SQL 语句成功，但是获取到的数据条数不等于 1
    if (results.length !== 1) return res.cc('登录失败！')

    // TODO：判断密码是否正确
    const compareResult = bcrypt.compareSync(userInfo.password, results[0].password)
    if (!compareResult) return res.cc('登录失败！')

    // TODO：在服务器端生成 Token 的字符串
    const user = { ...results[0], password: '', image: '' }
    // 对用户的信息进行加密，生成 Token 字符串
    // console.log(user);
    const tokenStr = jwt.sign(user, config.jwtSecretKey, { expiresIn: config.expiresIn })
    //角色权限
    let role;
    if (results[0].userGroup === "超级管理员") {
      role = "super";
    } else {
      role = "normal";
    }
    // 调用 res.send() 将 Token 响应给客户端
    res.send({
      status: 0,
      message: '登录成功！',
      role,
      token: 'Bearer ' + tokenStr,
    })
  })
}
/**
 * 添加账号
 */
exports.userAdd = (req, res) => {
  let  {username, password, userGroup} = req.body;
  // console.log(username, password, userGroup);
  // console.log(userInfo);

  const sql = `  select * from users where username=?`
  conn.query(sql,username, function (err, results) {
    if (err) {
      return res.cc(err)
    }
    // 用户名被占用
    if (results.length > 0) {
      return res.cc('用户名被占用,请更换其他用户名!')
    }
    password = bcrypt.hashSync(password, 10)
    const sql = `insert into users(ctime, username, password, userGroup, image) values
    ("${ctime()}","${username}", "${password}", "普通管理员", "default.jpg")`;
    conn.query(sql, (err, data) => {
      if (err) return res.cc(err)
      if (data.affectedRows > 0) {
        return res.cc("添加账号成功!", 0)
      } else {
        res.cc('"添加账号失败!"', 1)
      }
    });
  })

}
exports.role = (req, res) => {
  console.log('123',req.userGroup);
  let role;
  if (req.userGroup === "超级管理员") {
    role = "super";
  } else {
    role = "normal";
  }
  res.send({ role });
}