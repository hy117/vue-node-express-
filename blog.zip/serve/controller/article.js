const conn = require('../db/request')

//时间
const ctime = require('../util/time')

//获取文章列表
exports.getArticles = async (req, res, next) => {
  try {
    //处理请求
    res.send('post/users/login')
  } catch (err) {
    next(err)
  }
}
exports.getFeedArticles = (req, res) => {
  let { currentPage, pageSize } = req.body;
  if (!(currentPage && pageSize)) {
    res.cc('"参数错误!" ')
    return;
  }
  let sql = `select * from articles`;
  let total;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    total = data.length;
    let n = (currentPage - 1) * pageSize;
    sql += ` order by ctime desc limit ${n}, ${pageSize}`;
    conn.query(sql, (err, data) => {
      if (err) {
        return res.cc(err)
      }
      res.send({
        total,
        data,
      });
    });
  });
};

//获取所有文章
exports.getArticle = async (req, res) => {
  const sql = `select * from articles `
  conn.query(sql, (err, results) => {
    if (err) {
      return res.cc('获取失败')
    }
    res.send({
      status: 0,
      results,
      message: '请求成功'
    })
  })
}

exports.articleCs = async (req, res) => {
  const { content } = req.body
  let text =  JSON.stringify(content)
  const sql = `insert into articles(content) values(${text})`
  conn.query(sql, (err, results) => {
    if (err) return res.cc('执行错误')
    res.send({
      results,
      status:0,
      message:'创建成功'
    })
  })
}

// 创建文章
exports.createArticle = async (req, res) => {
  const { title, introduce, label,content } = req.body
  let text = JSON.stringify(content)
  if (!title || !introduce || !label || !content) {
    return res.cc('参数错误')
  }                                                                                                                               
  const sql = `insert into articles(title,introduce,label,ctime,content) values("${title}","${introduce}","${label}","${ctime()}",${text}) `
  conn.query(sql, (err, results) => {
    if (err) {
      return res.cc('新建文章失败')
    }
    res.send({
      status: 0,
      message: '新建成功',
      results
    })
  })
}



//删除文章
exports.deleteArticle = (req, res) => {
  let { id } = req.body;
  console.log();
  if (!id) {
    res.cc('"参数错误!"')
    return;
  }
  const sql = `delete from articles where id = ${id}`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    if (data.affectedRows > 0) {
      res.cc("删除成功!", 0)
    } else {
      res.cc("删除失败!")
    }
  });
}
/* 批量删除文章 */
exports.moveArticle = (req, res) => {
  let { id } = req.body;
  console.log(id);
  if (!id) {
    res.cc('参数错误!')
    return;
  }

  const sql = `delete from articles where id in (${JSON.parse(id).join(",")})`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    if (data.affectedRows > 0) {
      res.cc('批量删除成功!', 0)
    } else {
      res.cc('批量删除失败!')
    }
  });
};

/**
 * 编辑文章
 */
exports.editArticle = (req, res) => {
  let { title, label, id } = req.body;
  if (!(title && label && id)) {
    res.cc('参数错误!')
    return;
  }
  const sql = `update users set title="${title}", label="${label}" where id=${id}`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    if (data.affectedRows > 0) {
      res.cc('修改账号成功!', 0)
    }
  });
};
