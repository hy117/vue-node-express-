// 导入数据库操作模块
const conn = require('../db/request')
// 导入处理密码的模块
const bcrypt = require('bcryptjs')
//时间
const ctime = require('../util/time')

//图片
// const tup = require('../public/images/user/default.jpg')


//获取账号列表

exports.getUserInfo = (req, res) => {
  let { currentPage, pageSize } = req.query;
  if (!(currentPage && pageSize)) {
    res.cc('"参数错误!" ')
    return;
  }
  let sql = `select id,ctime,username,userGroup,image from users`;
  let total;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    total = data.length;
    let n = (currentPage - 1) * pageSize;
    sql += ` order by ctime desc limit ${n}, ${pageSize}`;
    conn.query(sql, (err, data) => {
      if (err) {
        return res.cc(err)
      }
      res.send({
        total,
        data,
        ctime: ctime()
      });
    });
  });
};
//删除账号
exports.deleteUser = (req, res) => {
  let { id } = req.query;
  if (!id) {
    res.cc('"参数错误!"')
    return;
  }
  const sql = `delete from users where id = ${id}`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    if (data.affectedRows > 0) {
      res.send({ code: 0, msg: "删除成功!" });
    } else {
      res.send({ code: 1, msg: "删除失败!" });
    }
  });
}
/* 批量删除 */
exports.moveDelete = (req, res) => {
  let { ids } = req.query;

  if (!ids) {
    res.cc('参数错误!')
    return;
  }

  const sql = `delete from users where id in (${JSON.parse(ids).join(",")})`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    if (data.affectedRows > 0) {
      res.cc('批量删除成功!', 0)
    } else {
      res.cc('批量删除失败!')
    }
  });
};

/**
 * 编辑
 */
exports.edit = (req, res) => {
  let { username, userGroup, id } = req.body;
  if (!(username && userGroup && id)) {
    res.cc('参数错误!')
    return;
  }
  const sql = `update users set username="${username}", userGroup="${userGroup}" where id=${id}`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    if (data.affectedRows > 0) {
      res.cc('修改账号成功!', 0)
    }
  });
};


// 更新用户基本信息的处理函数
exports.updateUserInfo = (req, res) => {
  // 定义待执行的 SQL 语句
  console.log(req.id);
  const sql = `update user set ? where id=?`
  // 调用 conn.query() 执行 SQL 语句并传递参数
  conn.query(sql, [req.body, req.body.id], (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 执行 SQL 语句成功，但是影响行数不等于 1
    if (results.affectedRows !== 1) return res.cc('更新用户的基本信息失败！')
    // 成功
    res.cc('更新用户信息成功！', 0)
  })
}

// 更新用户密码的处理函数
exports.updatePassword = (req, res) => {
  const { password, newPassword, twiceNewPassword } = req.body
  // 根据 id 查询用户的信息
  const sql = `select * from users where id=?`
  // 执行根据 id 查询用户的信息的 SQL 语句
  conn.query(sql, req.user.id, (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 判断结果是否存在
    if (results.length !== 1) return res.cc('用户不存在！')

    // 判断密码是否正确 
    if (newPassword != twiceNewPassword) {
      return res.cc('密码不一致，请重新输入')
    }
    // const compareResult = bcrypt.compareSync(req.body.oldPwd, results[0].password)
    // if (!compareResult) return res.cc('旧密码错误！')

    // 定义更新密码的 SQL 语句
    const sql = `update users set password=? where id=?`
    // 对新密码进行加密处理
    const newPwd = bcrypt.hashSync(twiceNewPassword, 10)
    // 调用 conn.query() 执行 SQL 语句
    conn.query(sql, [newPwd, req.user.id], (err, results) => {
      // 执行 SQL 语句失败
      if (err) return res.cc(err)
      // 判断影响的行数
      if (results.affectedRows !== 1) return res.cc('更新密码失败！')
      // 成功
      res.cc('更新密码成功', 0)
    })
  })
}

// 更新用户头像的处理函数
exports.updateAvatar = (req, res) => {
  // 1. 定义更新头像的 SQL 语句
  const sql = `update users set image=? where id=?`
  // 2. 调用 conn.query() 执行 SQL 语句
  conn.query(sql, [req.body.image, req.user.id], (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 影响的行数是否等于 1
    if (results.affectedRows !== 1) return res.cc('更换头像失败！')
    // 成功
    res.cc('更换头像成功！', 0)
  })
}
//个人信息
exports.userInfoGe = (req, res) => {
  const sql = `select id,ctime,username,userGroup,image from users where id=${req.user.id}`;
  conn.query(sql, (err, data) => {
    if (err) {
      return res.cc(err)
    }
    // if (data.length) {
    //   data[0].image =  "http://127.0.0.1:3000/public/images/user/" + data[0].image;
    // }
    res.send({
      data,
      status:0,
      message:'请求成功'
    })
  });
}