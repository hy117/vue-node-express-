//连接mysql
const mysql = require('mysql')
// 使用createConnection方法创建一个表示
// 与mysql数据库服务器之间连接的connection对象）
const conn = mysql.createConnection({
  host:'127.0.0.1',
  user:'root',
  password:'123456',
  database:'blog',
  multipleStatements:true  //支持执行多行sql语句
})
//connect()连接数据库
conn.connect()

module.exports = conn