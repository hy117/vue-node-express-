module.exports = function(options){
  options = options || {};
  options.sign = options.sign || 'yyyy-MM-dd HH:mm:ss';
  let _complete = function(n){
   return (n>9) ? n : '0' + n;
  }
  let d = new Date();
  let year = d.getFullYear();
  let month = _complete(d.getMonth()+1);
  let day = _complete(d.getDate());
  let hours = _complete(d.getHours());
  let minutes = _complete(d.getMinutes());
  let second = _complete(d.getSeconds());
  let result = options.sign;
  result = result.replace('yyyy', year);
  result = result.replace('MM', month);
  result = result.replace('dd', day);
  result = result.replace('HH', hours);
  result = result.replace('mm', minutes);
  result = result.replace('ss', second);
  return result;
 }
