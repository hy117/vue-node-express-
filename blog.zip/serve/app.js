const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const userRouter = require('./router/index')
const Joi = require('joi');
const errorHandler = require('./middleware/error-handler')

const app = express()
//端口
const PORT = process.env.PORT || 3000

//跨域
app.use(cors())
//配置解析表单请求体 application/json
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
//日志
app.use(morgan('dev'))
//封装res.cc
app.use((req, res, next) => {
  //status默认值为1，表示失败的情况
  //err的值，可能是一个错误对象，也可能是一个错误的描述字符串
  res.cc = function(err, status = 1) {
    res.send({
      status,
      message:err instanceof Error ? err.message : err,
    })
  }
  next()
})
// 错误中间件
const config = require('./config/config')
// 解析 token 的中间件
const expressJWT = require('express-jwt')
// 使用 .unless({ path: [/^\/api\//] }) 指定哪些接口不需要进行 Token 的身份认证
app.use(expressJWT({ secret: config.jwtSecretKey }).unless({ path: [/^\/api\//,/^\/qi\//] }))

//挂载统一处理服务器错误的中间件
// app.use(errorHandler())
// 导入配置文件



app.use(function (err, req, res, next) {
  // 数据验证失败
  if (err instanceof Joi.ValidationError) return res.cc(err)
  // 未知错误
  res.cc(err)
})

app.use(userRouter)

app.listen(PORT, () => {
  console.log(`express server running at http://127.0.0.1:${PORT}`)

})