const express = require('express')
const router = express.Router()
const articles = require('../controller/article')
//获取文章列表
router.post('/getArticles',articles.getArticles)
//获取文章列表
router.post('/getFeedArticles',articles.getFeedArticles)
//获取文章
router.post('/getArticle',articles.getArticle)
//创建文章
router.post('/createArticle',articles.createArticle)
//删除文章
router.post('/deleteArticle',articles.deleteArticle)
//批量删除文章
router.post('/moveArticle',articles.moveArticle)
//编辑文章
router.post('/editArticle',articles.editArticle)

//文章测试
router.post('/articleCs',articles.articleCs)
module.exports = router