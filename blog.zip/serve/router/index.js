const express = require('express')
const router = express.Router()

//用户相关路由
router.use('/api',require('./user'))
//用户资料相关路由
router.use('/my',require('./profile'))
//文章路由
router.use('/api',require('./article'))
//标签路由
router.use('/my',require('./tag'))
//前端请求
router.use('/api',require('./front'))
//前端登录注册
router.use('/api',require('./front'))
//前端留言
router.use('/my',require('./front'))
// 4. 向外导出路由对象
module.exports = router