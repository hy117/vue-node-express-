const express = require('express')
const router = express.Router()
const articles = require('../controller/front')
// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const { reg_login_util } = require('../util/user')
//获取文章
router.post('/getArticle',articles.getArticle)
//获取文章列表
router.post('/getArticleList',articles.getArticleList)
//获取id文章
router.post('/getIdArticle',articles.getIdArticle)
//观看次数
router.post('/see',articles.see)
//点赞接口
router.post('/fabulous',articles.fabulous)
//标签
router.post('/label',articles.label)
//登录
router.post('/HomeLogin',expressJoi(reg_login_util),articles.login)
//注册
router.post('/HomeRegister',expressJoi(reg_login_util),articles.register)
//获取用户信息
router.post('/userInfo',articles.userInfo)

module.exports = router