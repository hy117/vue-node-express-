const express = require('express')
const router = express.Router()
const profiles = require('../controller/profile')
// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const { update_userInfo_util,update_password_util,update_avatar_util } = require('../util/user')


// 获取用户列表
router.get('/userInfo', profiles.getUserInfo)
//删除用户
router.get('/deleteUser',profiles.deleteUser)
//批量删除用户
router.get('/moveDelete',profiles.moveDelete)
//编辑用户
router.post('/edit',profiles.edit)
// 更新用户信息的路由
router.post('/userInfo', expressJoi(update_userInfo_util), profiles.updateUserInfo)
// 修改密码
router.post('/updatePassword', expressJoi(update_password_util), profiles.updatePassword)
// 更换头像的路由
router.post('/update/avatar', profiles.updateAvatar)
//个人信息
router.post('/userInfoGe',profiles.userInfoGe)

module.exports = router